<?php $__env->startSection('title','Edit Operation Using Laravel'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-6 offset-3">
  <h3 class="text-center text-primary">Edit Form</h3>
<form action="<?php echo e(route('users.update',$edit->id)); ?>" method="post" autocomplete="off">
<?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <div class="mb-3 mt-3">
      <label for="email" class="form-label">First name:</label>
      <input type="text" class="form-control" placeholder="Enter FIrtsname" value="<?php echo e($edit->first_name); ?>" name="first_name">
      <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
    </div>
    <div class="mb-3">
      <label for="pwd" class="form-label">Last name:</label>
      <input type="text" class="form-control" placeholder="Enter Lastname" value="<?php echo e($edit->last_name); ?>" name="last_name">
      <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
    </div>
    <div class="mb-3">
      <label for="pwd" class="form-label">Gender:</label>
      <input type="radio"  name="gender" value="Male" <?php echo e($edit->gender=="Male"?"checked":""); ?> > Male
      <input type="radio"  name="gender" value="Female" <?php echo e($edit->gender=="Female"?"checked":""); ?>> Female
      <input type="radio"  name="gender" value="Others" <?php echo e($edit->gender=="Others"?"checked":""); ?>> Others<br>
      <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
    </div>
    <div class="mb-3">
      <label for="pwd" class="form-label">Qualifications:</label>
      <input type="text" class="form-control" id="pwd" placeholder="Enter Qualifications" value="<?php echo e($edit->qualifications); ?>" name="qualifications">
      <span class="text-danger"><?php echo e($errors->first('qualifications')); ?></span>
    </div>
    <button type="submit" class="btn btn-primary" name="submit">Update</button>
  </form>
  <div class="text-center text-success">
  <?php if(session('message')): ?>
  <?php echo e(session('message')); ?>

  <?php endif; ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\crud\resources\views/edit.blade.php ENDPATH**/ ?>