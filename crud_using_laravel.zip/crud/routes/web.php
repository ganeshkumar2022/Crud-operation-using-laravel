<?php

use App\Http\Controllers\CrudsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/",[CrudsController::class,"index"])->name('display_all');

Route::get("/insert",[CrudsController::class,"create"])->name('create');

Route::post("/store",[CrudsController::class,"store"])->name('users.store');


Route::get("/edit/{id}",[CrudsController::class,"edit"])->name('users.edit');
Route::get("/delete/{id}",[CrudsController::class,"destroy"])->name('users.delete');

Route::put("/update/{id}",[CrudsController::class,"update"])->name('users.update');
