<?php

namespace App\Http\Controllers;

use App\Models\Crud;
use Exception;
use Illuminate\Http\Request;

class CrudsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $datas=Crud::all();
        return view("home",compact('datas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'gender'=>'required',
            'qualifications'=>'required'
        ]);

        try
        {
        $crud=new Crud();
        $crud->first_name=$request->input('first_name');
        $crud->last_name=$request->input('last_name');
        $crud->gender=$request->input('gender');
        $crud->qualifications=$request->input('qualifications');
        $crud->save();

        return redirect()->route('create')->with('message','successfully inserted');
        }
        catch(Exception $e)
        {
            return redirect()->route('create')->with('message','Error to insert :'.$e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $edit=Crud::find($id);
        return view('edit',compact('edit'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'first_name'=>'required',
            'last_name'=>'required',
            'gender'=>'required',
            'qualifications'=>'required'
        ]);

        try
        {
        $user=Crud::find($id);
        $user->first_name=$request->input('first_name');
        $user->last_name=$request->input('last_name');
        $user->gender=$request->input('gender');
        $user->qualifications=$request->input('qualifications');
        $user->save();

        return redirect()->route('users.edit',$user->id)->with('message','Data updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('users.edit',$user->id)->with('message','Error to update');
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user=Crud::find($id);
        $user->delete();
        return redirect()->route('display_all')->with('message','User Deleted successfully');
    }
}
