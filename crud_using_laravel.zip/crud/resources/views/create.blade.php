@extends('layouts.master')
@section('title','Insert Operation Using Laravel')
@section('content')
<div class="row">
  <div class="col-md-6 offset-3">
  <h3 class="text-center text-primary">Registration Form</h3>
<form action="{{ route('users.store') }}" method="post" autocomplete="off">
    @csrf
    <div class="mb-3 mt-3">
      <label for="email" class="form-label">First name:</label>
      <input type="text" class="form-control" placeholder="Enter FIrtsname" value="{{ old('first_name') }}" name="first_name">
      <span class="text-danger">{{ $errors->first('first_name') }}</span>
    </div>
    <div class="mb-3">
      <label for="pwd" class="form-label">Last name:</label>
      <input type="text" class="form-control" placeholder="Enter Lastname" value="{{ old('last_name') }}" name="last_name">
      <span class="text-danger">{{ $errors->first('last_name') }}</span>
    </div>
    <div class="mb-3">
      <label for="pwd" class="form-label">Gender:</label>
      <input type="radio"  name="gender" value="Male" {{ old('gender')=="Male"?"checked":"" }} > Male
      <input type="radio"  name="gender" value="Female" {{ old('gender')=="Female"?"checked":"" }}> Female
      <input type="radio"  name="gender" value="Others" {{ old('gender')=="Others"?"checked":"" }}> Others<br>
      <span class="text-danger">{{ $errors->first('gender') }}</span>
    </div>
    <div class="mb-3">
      <label for="pwd" class="form-label">Qualifications:</label>
      <input type="text" class="form-control" id="pwd" placeholder="Enter Qualifications" value="{{ old('qualifications') }}" name="qualifications">
      <span class="text-danger">{{ $errors->first('qualifications') }}</span>
    </div>
    <button type="submit" class="btn btn-primary" name="submit">Insert</button>
  </form>
  <div class="text-center text-success">
  @if(session('message'))
  {{ session('message') }}
  @endif
</div>
</div>
</div>
@endsection
