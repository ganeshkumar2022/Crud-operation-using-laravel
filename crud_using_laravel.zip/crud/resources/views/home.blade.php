@extends('layouts.master')
@section('title','Crud using laravel - Display All records')
@section('content')
<div class="row">
    <div class="col-md-12">
        <h3 class="text-primary">
        <a href="{{ url('insert') }}" class="btn btn-primary btn-sm float-end">Insert Records</a>
        <center>Display All records</center>
        </h3>
        <table class="mt-3 table table-bordered table-sm">
            <tr class="table-primary">
                <th>S.No</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Gender</th>
                <th>Qualifications</th>
                <th>Manage</th>
            </tr>
            @foreach ($datas as $index => $data)
            <tr>
                <td>{{ $index+1 }}</td>
                <td>{{ $data->first_name }}</td>
                <td>{{ $data->last_name }}</td>
                <td>{{ $data->gender }}</td>
                <td>{{ $data->qualifications }}</td>
                <td>
                    <a href="{{ url('/edit/'.$data->id) }}" class="btn btn-success btn-sm">Edit</a>
                    <a href="{{ url('/delete/'.$data->id) }}" class="btn btn-danger btn-sm">Delete</a>
                </td>
            </tr>
            @endforeach
        </table>
    </div>
</div>
<?php
if(session('message'))
{
    ?>
    <script>
        alert("<?php echo session('message'); ?>");
    </script>
    <?php
}
?>
@endsection
